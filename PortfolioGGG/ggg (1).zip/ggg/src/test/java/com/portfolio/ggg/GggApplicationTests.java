package com.portfolio.ggg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GggApplicationTests {

	@Test
	void contextLoads() {
	}

}
