package com.portfolio.ggg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GggApplication {

	public static void main(String[] args) {
		SpringApplication.run(GggApplication.class, args);
	}

}
